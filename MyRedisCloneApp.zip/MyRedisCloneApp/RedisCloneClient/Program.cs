﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;

namespace RedisCloneClient
{
    class Program
    {
        public static string GetReponse(HttpWebResponse response)
        {
            //The response handling here is just from UI it can be handled in different ways in diiferent UIs
            var encoding = ASCIIEncoding.ASCII;
            using (var reader = new System.IO.StreamReader(response.GetResponseStream(), encoding))
            {
                var responseText = reader.ReadToEnd();
                if (responseText == "false" || responseText == "null" || responseText == "")
                    return "Object Not Found Or Expired";
                if (responseText == "true")
                    return "OK";
                return responseText;
            }
        }
        static void Main(string[] args)
        {
            bool isCommand = false;
            Console.WriteLine("This is the list of available commands:\n\n");
            Console.WriteLine("SET <VARNAME> <VALUE>: Set VARNAME to VALUE \nGET<VARNAME>: Retrieve and return value of VARNAME \nLPUSH<VARNAME> < VALUE >: PUSH VALUE to the lift of list VARNAME \nLPOP<VARNAME> < VALUE >: POP left value from list VARNAME \nLINDEX<VARNAME> < INDEX >: GET value at index INDEX from LIST VARNAME \nEXPIRES<VARNAME> < TIME >: EXPIRE value of VARNAME after TIME seconds\n\n");
            Console.WriteLine("Please Enter Your Command or 0 to exit:\n");
            string command = Console.ReadLine();
            while (command != "0")
            {
                isCommand = false;
                string[] commandDetails = command.Split(' ');
                if (commandDetails == null || commandDetails.Length == 0 || commandDetails[0] == "")
                {
                    Console.WriteLine("WRONG COMMAND!");
                }
                else
                {
                    switch (commandDetails[0].ToLower())
                    {
                        case "set":
                            if(!(commandDetails.Length ==3))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            byte[] data = Encoding.ASCII.GetBytes($"Name={commandDetails[1]}&Value={commandDetails[2]}");
                            WebRequest setRequest = WebRequest.Create("https://localhost:44358/RedisCloneAPI/Set");
                            setRequest.Method = "POST";
                            setRequest.ContentType = "application/x-www-form-urlencoded";
                            setRequest.ContentLength = data.Length;
                            using (Stream stream = setRequest.GetRequestStream())
                            {
                                stream.Write(data, 0, data.Length);
                            }
                            try
                            {
                                var response = (HttpWebResponse)setRequest.GetResponse();
                                Console.WriteLine(response.StatusDescription);

                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }

                            break;
                        case "get":
                            if (!(commandDetails.Length == 2))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            string url = string.Format("https://localhost:44358/RedisCloneAPI/Get?varName={0}", commandDetails[1]);
                            HttpWebRequest getRequest = (HttpWebRequest)WebRequest.Create(url);
                            getRequest.Method = "GET";
                            try
                            {
                                var response = (HttpWebResponse)getRequest.GetResponse();
                                Console.WriteLine( GetReponse(response).ToString());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                            break;
                        case "lpush":
                            if (!(commandDetails.Length == 3))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            byte[] pushData = Encoding.ASCII.GetBytes($"Name={commandDetails[1]}&Value={commandDetails[2]}");
                            WebRequest pushRequest = WebRequest.Create("https://localhost:44358/RedisCloneAPI/LPush");
                            pushRequest.Method = "POST";
                            pushRequest.ContentType = "application/x-www-form-urlencoded";
                            pushRequest.ContentLength = pushData.Length;
                            using (Stream stream = pushRequest.GetRequestStream())
                            {
                                stream.Write(pushData, 0, pushData.Length);
                            }
                            try
                            {
                                var response = (HttpWebResponse)pushRequest.GetResponse();
                                Console.WriteLine(GetReponse(response).ToString());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }

                            break;
                        case "lpop":
                            if (!(commandDetails.Length == 2))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            byte[] popData = Encoding.ASCII.GetBytes($"Name={commandDetails[1]}");
                            WebRequest popRequest = WebRequest.Create("https://localhost:44358/RedisCloneAPI/LPop");
                            popRequest.Method = "POST";
                            popRequest.ContentType = "application/x-www-form-urlencoded";
                            popRequest.ContentLength = popData.Length;
                            using (Stream stream = popRequest.GetRequestStream())
                            {
                                stream.Write(popData, 0, popData.Length);
                            }
                            try
                            {
                                var response = (HttpWebResponse)popRequest.GetResponse();
                                Console.WriteLine(GetReponse(response).ToString());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                            break;
                        case "lindex":
                            if (!(commandDetails.Length == 3))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            string lindexUrl = string.Format("https://localhost:44358/RedisCloneAPI/LIndex?name={0}&index={1}", commandDetails[1],commandDetails[2]);
                            HttpWebRequest lindexRequest = (HttpWebRequest)WebRequest.Create(lindexUrl);
                            lindexRequest.Method = "GET";
                            try
                            {
                                var response = (HttpWebResponse)lindexRequest.GetResponse();
                                Console.WriteLine(GetReponse(response));
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }
                            break;
                        case "expires":
                            if (!(commandDetails.Length == 3))
                            {
                                Console.WriteLine("WRONG COMMAND!");
                                break;
                            }
                            isCommand = true;
                            byte[] expiresData = Encoding.ASCII.GetBytes($"Name={commandDetails[1]}&Seconds={commandDetails[2]}");
                            WebRequest expiresRequest = WebRequest.Create("https://localhost:44358/RedisCloneAPI/Expires");
                            expiresRequest.Method = "POST";
                            expiresRequest.ContentType = "application/x-www-form-urlencoded";
                            expiresRequest.ContentLength = expiresData.Length;
                            using (Stream stream = expiresRequest.GetRequestStream())
                            {
                                stream.Write(expiresData, 0, expiresData.Length);
                            }
                            try
                            {
                                var response = (HttpWebResponse)expiresRequest.GetResponse();
                                Console.WriteLine(GetReponse(response).ToString());
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }

                            break;
                    }
                }
                if (!isCommand)
                {
                    Console.WriteLine("Syntax Error.");
                   
                }
                command = Console.ReadLine();
            }



        }
        
    }
}
