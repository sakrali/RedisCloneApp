The main purpose of this application is to create a cache memory like REDIS.
Before you start, RedisCloneApplication Solution should be launched.
Then you can start the console application where a menu will show up to show you all available functions.
The console application is in RedisCloneClient/RedisCloneClient.sln
SET
GET
LPOP
LPUSH
LINDEX
EXPIRES
Each one of them has it is description beside it.
You can start using the app by entering commands.


