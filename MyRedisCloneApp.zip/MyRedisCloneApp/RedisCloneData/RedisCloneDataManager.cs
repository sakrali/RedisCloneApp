﻿using Extensions;
using IRedisCloneData;
using RedisCloneEntities;
using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisCloneData
{
   public class RedisCloneDataManager : IRedisCloneDataManager
    {
        public static Dictionary<string, RedisCloneEntity> RedisCloneItems = new Dictionary<string, RedisCloneEntity>();
        public void Set(string name,object value)
        {
            var itemToSet = RedisCloneItems.GetOrCreate(name);
            itemToSet.Value = value;
            itemToSet.ExpiryDate = null;
        }
        public object Get(string name)
        {
            if (RedisCloneItems.ContainsKey(name))
            {
                var item = RedisCloneItems[name];
                if (!ItemExpired(item))
                    return item.Value;
            }
            return null;
        }
        public bool LPush (string listName ,object value)
        {
            if (RedisCloneItems.ContainsKey(listName))
            {
                var item = RedisCloneItems[listName];
                if (item != null && !ItemExpired(item) && MyExtensions.IsList(item.Value))
                {
                    IList collection = (IList)item.Value;
                    collection.Add(value);
                    return true;
                }
            }
            return false;
        }
        public object LPop(string listName)
        {
            if (RedisCloneItems.ContainsKey(listName))
            {
                var item = RedisCloneItems[listName];
                if (item != null && !ItemExpired(item) && MyExtensions.IsList(item.Value))
                {
                    IList itemList = (IList)item.Value;
                    if (itemList.Count > 0)
                    {
                        var poppedValue = itemList[0];
                        itemList.RemoveAt(0);
                        return poppedValue;
                    }
                }
            }
            return null;
        }
        public object LIndex(string listName ,int index)
        {
            if (RedisCloneItems.ContainsKey(listName))
            {
                var item = RedisCloneItems[listName];
                if (item != null && !ItemExpired(item) && MyExtensions.IsList(item.Value))
                {
                    IList collection = (IList)item.Value;
                    if (collection.Count >= index)
                    {
                        return collection[index];
                    }
                }
            }
            return null;
        }
        public bool Expires (string name,int seconds)
        {
            if (RedisCloneItems.ContainsKey(name))
            {
                var item = RedisCloneItems[name];
                if (!item.ExpiryDate.HasValue)
                {
                    item.ExpiryDate = DateTime.Now.AddSeconds(seconds);
                    return true;
                }
            }
            return false;
        }
        public bool ItemExpired(RedisCloneEntity redisCloneEntity)
        {
            var itemExpiryDate = redisCloneEntity.ExpiryDate;
            if (itemExpiryDate == null || itemExpiryDate >= DateTime.Now)
                return false;
            return true;
        }
    }
}
