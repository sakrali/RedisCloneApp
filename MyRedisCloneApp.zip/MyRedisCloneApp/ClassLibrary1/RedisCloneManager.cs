﻿using IRedisCloneData;
using RedisCloneData;
using RedisCloneEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RedisCloneBusiness
{
    public class RedisCloneManager
    {
        static readonly object _object = new object();
        IRedisCloneDataManager _redisCloneDataManager = new RedisCloneDataManager();
        public void Set(string name, string value)
        {
            if (name == null || value == null)
                throw new Exception("One of the inputs is NULL");
            Monitor.Enter(_object);
            try
            {
                int integerValue;
                var isNumeric = int.TryParse(value, out integerValue);
                if (!isNumeric && value.Contains(","))
                {
                    var listValue = value.Split(",").ToList();
                    List<int> intListValue;
                    if (isIntList(listValue, out intListValue))
                        _redisCloneDataManager.Set(name, intListValue);
                    else
                        _redisCloneDataManager.Set(name, listValue);
                }
                else
                    _redisCloneDataManager.Set(name, isNumeric ? integerValue : value);
            }
            finally
            {
                Monitor.Exit(_object);
            }
        }
        public object Get(string varName)
        {
            if (varName == null)
                throw new Exception("The input is NULL");
            return _redisCloneDataManager.Get(varName);
        }
        public bool LPush(string listName, string value)
        {
            if (listName == null || value == null)
                throw new Exception("One of the inputs is NULL");
            Monitor.Enter(_object);
            try
            {
                int integerValue;
                var isNumeric = int.TryParse(value, out integerValue);
                return _redisCloneDataManager.LPush(listName, isNumeric ? integerValue : value);
            }
            finally
            {
                Monitor.Exit(_object);
            }
        }
        public object LPop(string listName)
        {
            if (listName == null )
                throw new Exception("One of the inputs is NULL");
            Monitor.Enter(_object);
            try
            {
                return _redisCloneDataManager.LPop(listName);
            }
            finally
            {
                Monitor.Exit(_object);
            }
        }
        public object LIndex(string listName, string index)
        {
            if (listName == null || index == null)
                throw new Exception("One of the inputs is NULL");
            Monitor.Enter(_object);
            try
            {
                int integerValue;
                var isNumeric = int.TryParse(index, out integerValue);
                if (isNumeric)
                    return _redisCloneDataManager.LIndex(listName, integerValue);
            }
            finally
            {
                Monitor.Exit(_object);
            }
            return null;
        }
        public bool Expires(string name, string seconds)
        {
            if (name == null || seconds == null)
                throw new Exception("One of the inputs is NULL");
            Monitor.Enter(_object);
            try
            {
                int integerValue;
                var isNumeric = int.TryParse(seconds, out integerValue);
                if (isNumeric)
                    return _redisCloneDataManager.Expires(name, integerValue);
            }
            finally
            {
                Monitor.Exit(_object);
            }
            return false;
        }
        public bool isIntList(List<string> inputList, out List<int> intInputList)
        {
            intInputList = new List<int>();
            int counter = 0;
            foreach (var item in inputList)
            {
                int integerValue;
                if (!(int.TryParse(item, out integerValue)))
                    return false;
                else
                    intInputList.Add(integerValue);
                counter++;
            }
            return true;
        }
    }
}
