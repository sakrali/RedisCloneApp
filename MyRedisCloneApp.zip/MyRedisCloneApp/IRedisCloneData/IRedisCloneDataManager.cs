﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisCloneData
{
    public interface IRedisCloneDataManager
    {
        void Set(string name,object value);
        object Get(string name);
        bool LPush(string listName, object value);
        object LPop(string listName);
        object LIndex(string listName, int index);
        bool Expires(string name, int seconds);
    }
}
