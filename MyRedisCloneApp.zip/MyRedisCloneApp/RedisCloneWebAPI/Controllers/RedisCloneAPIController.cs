﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using RedisCloneBusiness;
using RedisCloneEntities;

namespace RedisCloneWebAPI.Controllers
{
    public class RedisCloneAPIController :ApiController
    {
        
        RedisCloneManager _redisCloneManager;
        public RedisCloneAPIController(RedisCloneManager redisCloneManager)
        {
            _redisCloneManager = redisCloneManager;
        }

        [HttpPost]
        public void Set(RedisCloneInput input)
        {
            if (input != null)
                _redisCloneManager.Set(input.Name, input.Value);
        }
        [HttpGet]
        public object Get(string varName)
        {
            if (varName != null)
                return _redisCloneManager.Get(varName);
            return null;
        }
        [HttpPost]
        public bool LPush(RedisCloneInput input)
        {
            if (input != null)
                return _redisCloneManager.LPush(input.Name, input.Value);
            else
                throw new Exception("input is NULL");
        }
        [HttpPost]
        public object LPop(RedisClonePopInput input)
        {
            if (input != null)
                return _redisCloneManager.LPop(input.Name);
            else
                throw new Exception("input is NULL");
        }
        [HttpGet]
        public object lindex(string name, string index)
        {
            if (name != null)
                return _redisCloneManager.LIndex(name, index);
            else
                throw new Exception("variable name is null");
        }
        [HttpPost]
        public bool Expires(RedisCloneExpiresInput input)
        {
            if (input != null)
                return _redisCloneManager.Expires(input.Name, input.Seconds);
            else
                throw new Exception("input is NULL");
        }
    }
}
